# chess_piece > 2024-06-15 12:30pm
https://universe.roboflow.com/objdetection-telvm/chess_piece-nu1xx

Provided by a Roboflow user
License: CC BY 4.0

