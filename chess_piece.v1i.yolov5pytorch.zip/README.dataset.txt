# chess_piece > 2024-06-15 4:41am
https://universe.roboflow.com/naitik-patel/chess_piece-nu1xx

Provided by a Roboflow user
License: CC BY 4.0

